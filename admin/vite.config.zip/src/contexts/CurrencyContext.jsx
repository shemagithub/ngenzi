import { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';
import { backendurl } from '../config/constants';

const CurrencyContext = createContext();

// Exchange rates (using RWF as base currency for Rwanda)
const EXCHANGE_RATES = {
  RWF: 1,        // Base currency (Rwandan Francs)
  USD: 0.00081,  // 1 RWF = 0.00081 USD
  EUR: 0.00075,  // 1 RWF = 0.00075 EUR
  GBP: 0.00064,  // 1 RWF = 0.00064 GBP
  AED: 0.0030,   // 1 RWF = 0.0030 AED
  JPY: 0.12,     // 1 RWF = 0.12 JPY
  INR: 0.069,    // 1 RWF = 0.069 INR
};

const CURRENCY_SYMBOLS = {
  INR: '₹',
  USD: '$',
  EUR: '€',
  GBP: '£',
  AED: 'د.إ',
  JPY: '¥',
  RWF: 'Fr',
};

export const CurrencyProvider = ({ children }) => {
  const [currency, setCurrency] = useState('RWF');
  const [loading, setLoading] = useState(true);

  // Fetch settings currency on mount
  useEffect(() => {
    const fetchSettingsCurrency = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get(`${backendurl}/api/settings`, {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });

        if (response.data.success && response.data.settings?.currency) {
          setCurrency(response.data.settings.currency);
        }
      } catch (error) {
        console.error('Error fetching settings currency:', error);
        // Keep default RWF if fetch fails
      } finally {
        setLoading(false);
      }
    };

    fetchSettingsCurrency();
  }, []);

  const convertPrice = (price) => {
    if (!price || isNaN(price)) return 0;
    const rate = EXCHANGE_RATES[currency] || 1;
    return (Number(price) * rate).toFixed(2);
  };

  const formatPrice = (price) => {
    const convertedPrice = convertPrice(price);
    const symbol = CURRENCY_SYMBOLS[currency] || 'Fr';
    
    // Format number with commas
    const formattedNumber = Number(convertedPrice).toLocaleString('en-IN', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    });

    return `${symbol}${formattedNumber}`;
  };

  const getCurrencySymbol = () => {
    return CURRENCY_SYMBOLS[currency] || 'Fr';
  };

  const getCurrencyCode = () => {
    return currency;
  };

  return (
    <CurrencyContext.Provider
      value={{
        currency,
        setCurrency,
        convertPrice,
        formatPrice,
        getCurrencySymbol,
        getCurrencyCode,
        currencies: Object.keys(CURRENCY_SYMBOLS),
        currencySymbols: CURRENCY_SYMBOLS,
        loading,
      }}
    >
      {children}
    </CurrencyContext.Provider>
  );
};

export const useCurrency = () => {
  const context = useContext(CurrencyContext);
  if (!context) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return context;
};

