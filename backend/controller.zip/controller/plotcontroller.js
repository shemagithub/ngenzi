import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import imagekit, { isImageKitConfigured } from "../config/imagekit.js";
import Plot from "../models/plotmodel.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const addplot = async (req, res) => {
    try {
        console.log('Request body keys:', Object.keys(req.body));
        console.log('Request files:', req.files ? Object.keys(req.files) : 'No files');
        
        // Parse amenities from FormData array format
        let amenities = [];
        if (Array.isArray(req.body.amenities)) {
            amenities = req.body.amenities.filter(Boolean);
        } else if (typeof req.body.amenities === 'string' && req.body.amenities.trim()) {
            try {
                amenities = JSON.parse(req.body.amenities);
                if (!Array.isArray(amenities)) {
                    amenities = [amenities];
                }
            } catch {
                amenities = [req.body.amenities];
            }
        } else {
            const amenityKeys = Object.keys(req.body).filter(key => key.startsWith('amenities['));
            if (amenityKeys.length > 0) {
                amenities = amenityKeys
                    .sort((a, b) => {
                        const indexA = parseInt(a.match(/\[(\d+)\]/)?.[1] || '0');
                        const indexB = parseInt(b.match(/\[(\d+)\]/)?.[1] || '0');
                        return indexA - indexB;
                    })
                    .map(key => req.body[key])
                    .filter(Boolean);
            }
        }
        
        // Extract and convert data types
        const title = req.body.title?.trim();
        const location = req.body.location?.trim();
        const price = parseFloat(req.body.price);
        const area = parseFloat(req.body.area || req.body.sqft); // Support both 'area' and 'sqft'
        const areaUnit = req.body.areaUnit?.trim() || 'sqft';
        const type = req.body.type?.trim() || 'Plot';
        const availability = req.body.availability?.trim();
        const description = req.body.description?.trim();
        const phone = req.body.phone?.trim() || '';
        const plotNumber = req.body.plotNumber?.trim() || null;
        const surveyNumber = req.body.surveyNumber?.trim() || null;
        const facing = req.body.facing?.trim() || null;
        const cornerPlot = req.body.cornerPlot === 'true' || req.body.cornerPlot === true;
        const approvedLayout = req.body.approvedLayout === 'true' || req.body.approvedLayout === true;

        // Validate required fields
        if (!title || !location || !availability || !description) {
            return res.status(400).json({ 
                message: "Missing required fields: title, location, availability, and description are required", 
                success: false 
            });
        }

        // Validate numeric fields
        if (isNaN(price) || price < 0) {
            return res.status(400).json({ 
                message: "Invalid price: must be a positive number", 
                success: false 
            });
        }
        if (isNaN(area) || area < 0) {
            return res.status(400).json({ 
                message: "Invalid area: must be a positive number", 
                success: false 
            });
        }

        // Handle images
        console.log('📁 Checking for uploaded images...');
        console.log('req.files keys:', req.files ? Object.keys(req.files) : 'No files object');
        
        const frontImageFile = req.files?.frontImage?.[0];
        const image1 = req.files?.image1?.[0];
        const image2 = req.files?.image2?.[0];
        const image3 = req.files?.image3?.[0];
        const image4 = req.files?.image4?.[0];
        const images = [image1, image2, image3, image4].filter((item) => item !== undefined);
        
        console.log(`📸 Found ${images.length} image(s) to process`);
        if (images.length > 0) {
            images.forEach((img, idx) => {
                console.log(`  Image ${idx + 1}: ${img.originalname} (${img.size} bytes) at ${img.path}`);
            });
        }
        
        // Helper function to save a single image (with ImageKit fallback to local storage)
        const saveImage = async (imageFile, isFrontImage = false) => {
            if (!imageFile) return null;
            
            let imageKitAttempted = false;
            let imageKitSucceeded = false;
            let imageUrl = null;
            
            // Try ImageKit first if configured
            if (isImageKitConfigured && imagekit) {
                imageKitAttempted = true;
                try {
                    console.log(`🔄 Attempting ImageKit upload for ${isFrontImage ? 'front image' : 'image'}...`);
                    const filePath = imageFile.path;
                    if (fs.existsSync(filePath)) {
                        const fileBuffer = fs.readFileSync(filePath);
                        const folderPath = isFrontImage ? "Plot/Front" : "Plot";
                        
                        const result = await imagekit.upload({
                            file: fileBuffer,
                            fileName: imageFile.originalname,
                            folder: folderPath,
                        });
                        
                        fs.unlink(filePath, (err) => {
                            if (err) console.error("Error deleting temp file:", err);
                        });
                        
                        imageUrl = result.url;
                        imageKitSucceeded = true;
                        console.log(`✅ Image uploaded to ImageKit: ${imageUrl}`);
                    } else {
                        console.error(`❌ ImageKit: File path does not exist: ${filePath}`);
                        throw new Error('File path does not exist for ImageKit upload');
                    }
                } catch (imageKitError) {
                    console.error(`❌ ImageKit upload failed: ${imageKitError.message}`);
                    console.log(`📦 Falling back to local storage...`);
                    imageKitSucceeded = false;
                }
            }
            
            // Save locally if ImageKit not configured or ImageKit failed
            if (!imageKitSucceeded) {
                try {
                    const baseUploadsDir = path.join(__dirname, '..', 'uploads');
                    if (!fs.existsSync(baseUploadsDir)) {
                        fs.mkdirSync(baseUploadsDir, { recursive: true });
                        console.log(`📁 Created base uploads directory: ${baseUploadsDir}`);
                    }
                    
                    const uploadsDir = path.join(__dirname, '..', 'uploads', 'plots');
                    if (!fs.existsSync(uploadsDir)) {
                        fs.mkdirSync(uploadsDir, { recursive: true });
                        console.log(`📁 Created plots directory: ${uploadsDir}`);
                    } else {
                        console.log(`📁 Plots directory already exists: ${uploadsDir}`);
                    }
                    
                    const filePath = imageFile.path;
                    console.log(`📂 Checking temp file path for local save: ${filePath}`);
                    console.log(`   File exists: ${fs.existsSync(filePath)}`);
                    
                    if (!filePath) {
                        console.error(`❌ Local Save: Image file path is undefined or null!`);
                        console.error(`   imageFile object:`, imageFile);
                        return null;
                    } else if (fs.existsSync(filePath)) {
                        const timestamp = Date.now();
                        const randomSuffix = Math.random().toString(36).substring(2, 8);
                        const ext = path.extname(imageFile.originalname) || '.jpg';
                        const baseName = path.basename(imageFile.originalname, ext).replace(/[^a-zA-Z0-9]/g, '_');
                        const prefix = isFrontImage ? 'front-' : '';
                        const newFileName = `${prefix}plot-${timestamp}-${randomSuffix}-${baseName}${ext}`;
                        const newFilePath = path.join(uploadsDir, newFileName);
                        
                        console.log(`📝 Preparing to save image locally:`);
                        console.log(`   Source: ${filePath}`);
                        console.log(`   Destination: ${newFilePath}`);
                        console.log(`   File name: ${newFileName}`);
                        
                        try {
                            fs.copyFileSync(filePath, newFilePath);
                            if (fs.existsSync(newFilePath)) {
                                const stats = fs.statSync(newFilePath);
                                console.log(`✅ Image saved locally successfully!`);
                                console.log(`   File path: ${newFilePath}`);
                                console.log(`   File size: ${stats.size} bytes`);
                                
                                try {
                                    fs.unlinkSync(filePath);
                                    console.log(`🗑️ Temporary file deleted: ${filePath}`);
                                } catch (unlinkErr) {
                                    console.error(`⚠️ Error deleting temp file: ${unlinkErr.message}`);
                                }
                                
                                imageUrl = `/uploads/plots/${newFileName}`;
                                console.log(`✅ Local Image URL generated: ${imageUrl}`);
                            } else {
                                console.error(`❌ Failed to save image locally - file does not exist after copy`);
                                console.error(`   Expected path: ${newFilePath}`);
                                return null;
                            }
                        } catch (copyError) {
                            console.error(`❌ Error copying image file locally:`, copyError);
                            console.error(`   Error message: ${copyError.message}`);
                            console.error(`   Error stack: ${copyError.stack}`);
                            return null;
                        }
                    } else {
                        console.error(`❌ Local Save: Image file path does not exist: ${filePath}`);
                        console.error(`   Current working directory: ${process.cwd()}`);
                        return null;
                    }
                } catch (localSaveError) {
                    console.error(`❌ Local save error:`, localSaveError);
                    console.error(`   Error message: ${localSaveError.message}`);
                    return null;
                }
            }
            
            return imageUrl;
        };
        
        // Save frontImage
        let frontImageUrl = null;
        if (frontImageFile) {
            frontImageUrl = await saveImage(frontImageFile, true);
        }
        
        // Upload images using the same saveImage function
        let imageUrls = [];
        if (images.length > 0) {
            try {
                console.log(`📸 Processing ${images.length} image(s)...`);
                imageUrls = await Promise.all(
                    images.map(async (item) => {
                        return await saveImage(item, false);
                    })
                );
                imageUrls = imageUrls.filter(url => url !== null);
                console.log(`\n📊 Image processing complete: ${imageUrls.length}/${images.length} images saved`);
            } catch (imageError) {
                console.error("Error processing images:", imageError);
                console.warn("⚠️  Continuing without images due to error");
            }
        }
        
        console.log(`\n📸 Total images to save to database: ${imageUrls.length}`);
        if (imageUrls.length > 0) {
            console.log('   Image URLs:', imageUrls);
        } else {
            console.warn('   ⚠️  WARNING: No images will be saved!');
        }
        
        // Prepare plot data
        const plotData = {
            title: title,
            location: location,
            price: Number(price),
            area: Number(area),
            areaUnit: areaUnit,
            type: type,
            availability: availability,
            description: description,
            amenities: Array.isArray(amenities) && amenities.length > 0 ? amenities : [],
            frontImage: frontImageUrl || null,
            image: Array.isArray(imageUrls) ? imageUrls : [],
            phone: phone || 'N/A',
            plotNumber: plotNumber,
            surveyNumber: surveyNumber,
            facing: facing,
            cornerPlot: cornerPlot,
            approvedLayout: approvedLayout
        };
        
        console.log('\n💾 Plot data to save:');
        console.log(`   Title: ${plotData.title}`);
        console.log(`   Location: ${plotData.location}`);
        console.log(`   Price: ${plotData.price}`);
        console.log(`   Front Image: ${plotData.frontImage || 'None'}`);
        console.log(`   Images array length: ${plotData.image.length}`);
        console.log(`   Images:`, plotData.image);
        console.log(`   Image field type: ${typeof plotData.image} (isArray: ${Array.isArray(plotData.image)})`);
        
        // Ensure image is always an array
        if (!Array.isArray(plotData.image)) {
            console.warn('⚠️  Warning: image is not an array, converting...');
            plotData.image = [];
        }
        
        // Create plot in database
        console.log('\n💾 Saving to database...');
        const plot = await Plot.create(plotData);
        console.log(`✅ Plot created with ID: ${plot.id}`);
        
        // Verify the plot was created correctly
        const savedPlot = await Plot.findByPk(plot.id);
        if (!savedPlot) {
            throw new Error('Plot was not saved correctly');
        }
        
        const savedData = savedPlot.toJSON();
        console.log(`📊 Saved plot verification:`);
        console.log(`   ID: ${savedData.id}`);
        console.log(`   Title: ${savedData.title}`);
        console.log(`   Front Image in DB: ${savedData.frontImage || 'None'}`);
        console.log(`   Images in DB (type: ${Array.isArray(savedData.image) ? 'array' : typeof savedData.image}):`, savedData.image);
        console.log(`   Image count: ${Array.isArray(savedData.image) ? savedData.image.length : 'N/A'}`);
        
        // Get base URL for converting relative paths to absolute URLs
        const baseUrl = `${req.protocol}://${req.get('host')}`;
        
        // Convert frontImage to full URL if it's a local path
        if (savedData.frontImage && typeof savedData.frontImage === 'string' && savedData.frontImage.startsWith('/uploads/')) {
            savedData.frontImage = `${baseUrl}${savedData.frontImage}`;
        }
        
        // Ensure images and amenities are arrays in the response
        if (!Array.isArray(savedData.image)) {
            if (typeof savedData.image === 'string') {
                try {
                    savedData.image = JSON.parse(savedData.image);
                } catch {
                    savedData.image = [savedData.image];
                }
            } else {
                savedData.image = [];
            }
        }
        
        // Convert local paths to full URLs
        savedData.image = savedData.image.map(img => {
            if (typeof img === 'string' && img.startsWith('/uploads/')) {
                return `${baseUrl}${img}`;
            }
            return img;
        });
        
        if (!Array.isArray(savedData.amenities)) {
            if (typeof savedData.amenities === 'string') {
                try {
                    savedData.amenities = JSON.parse(savedData.amenities);
                } catch {
                    savedData.amenities = [];
                }
            } else {
                savedData.amenities = [];
            }
        }

        res.json({ 
            message: "Plot added successfully", 
            success: true, 
            plot: savedData 
        });
    } catch (error) {
        console.error("Error adding plot:", error);
        res.status(500).json({ 
            message: error.message || "Server Error", 
            success: false,
            error: process.env.NODE_ENV === 'development' ? error.stack : undefined
        });
    }
};

const listplot = async (req, res) => {
    try {
        const plots = await Plot.findAll({
            order: [['createdAt', 'DESC']]
        });
        
        const baseUrl = `${req.protocol}://${req.get('host')}`;
        
        const plotData = plots.map(plot => {
            const data = plot.toJSON();
            
            if (data.frontImage && typeof data.frontImage === 'string' && data.frontImage.startsWith('/uploads/')) {
                data.frontImage = `${baseUrl}${data.frontImage}`;
            }
            
            if (data.image) {
                if (typeof data.image === 'string') {
                    try {
                        data.image = JSON.parse(data.image);
                    } catch {
                        data.image = [data.image];
                    }
                }
                if (!Array.isArray(data.image)) {
                    data.image = [];
                }
                
                data.image = data.image.map(img => {
                    if (typeof img === 'string' && img.startsWith('/uploads/')) {
                        return `${baseUrl}${img}`;
                    }
                    return img;
                });
            } else {
                data.image = [];
            }
            
            if (data.amenities) {
                if (typeof data.amenities === 'string') {
                    try {
                        data.amenities = JSON.parse(data.amenities);
                    } catch {
                        data.amenities = [data.amenities];
                    }
                }
                if (!Array.isArray(data.amenities)) {
                    data.amenities = [];
                }
            } else {
                data.amenities = [];
            }
            
            return data;
        });
        
        res.json({ success: true, plots: plotData });
    } catch (error) {
        console.error("Error listing plots:", error);
        res.status(500).json({ message: "Server Error", success: false });
    }
};

const removeplot = async (req, res) => {
    try {
        const deletedCount = await Plot.destroy({ where: { id: req.body.id } });
        if (deletedCount === 0) {
            return res.status(404).json({ message: "Plot not found", success: false });
        }
        return res.json({ message: "Plot removed successfully", success: true });
    } catch (error) {
        console.log("Error removing plot: ", error);
        return res.status(500).json({ message: "Server Error", success: false });
    }
};

const updateplot = async (req, res) => {
    try {
        const plotId = req.body.id;
        if (!plotId) {
            return res.status(400).json({ message: "Plot ID is required", success: false });
        }

        // Parse amenities
        let amenities = [];
        if (req.body.amenities) {
            if (Array.isArray(req.body.amenities)) {
                amenities = req.body.amenities;
            } else if (typeof req.body.amenities === 'string') {
                try {
                    amenities = JSON.parse(req.body.amenities);
                    if (!Array.isArray(amenities)) {
                        amenities = [amenities];
                    }
                } catch {
                    amenities = [req.body.amenities];
                }
            } else {
                const amenityKeys = Object.keys(req.body).filter(key => key.startsWith('amenities['));
                if (amenityKeys.length > 0) {
                    amenities = amenityKeys
                        .sort((a, b) => {
                            const indexA = parseInt(a.match(/\[(\d+)\]/)?.[1] || '0');
                            const indexB = parseInt(b.match(/\[(\d+)\]/)?.[1] || '0');
                            return indexA - indexB;
                        })
                        .map(key => req.body[key])
                        .filter(Boolean);
                }
            }
        }

        // Build update data
        const updateData = {};
        if (req.body.title) updateData.title = req.body.title.trim();
        if (req.body.location) updateData.location = req.body.location.trim();
        if (req.body.price) updateData.price = parseFloat(req.body.price);
        if (req.body.area || req.body.sqft) updateData.area = parseFloat(req.body.area || req.body.sqft);
        if (req.body.areaUnit) updateData.areaUnit = req.body.areaUnit.trim();
        if (req.body.type) updateData.type = req.body.type.trim();
        if (req.body.availability) updateData.availability = req.body.availability.trim();
        if (req.body.description) updateData.description = req.body.description.trim();
        if (req.body.phone) updateData.phone = req.body.phone.trim();
        if (req.body.plotNumber !== undefined) updateData.plotNumber = req.body.plotNumber?.trim() || null;
        if (req.body.surveyNumber !== undefined) updateData.surveyNumber = req.body.surveyNumber?.trim() || null;
        if (req.body.facing !== undefined) updateData.facing = req.body.facing?.trim() || null;
        if (req.body.cornerPlot !== undefined) updateData.cornerPlot = req.body.cornerPlot === 'true' || req.body.cornerPlot === true;
        if (req.body.approvedLayout !== undefined) updateData.approvedLayout = req.body.approvedLayout === 'true' || req.body.approvedLayout === true;
        if (amenities.length > 0) updateData.amenities = amenities;

        // Handle images (similar to addplot)
        const frontImageFile = req.files?.frontImage?.[0];
        const image1 = req.files?.image1?.[0];
        const image2 = req.files?.image2?.[0];
        const image3 = req.files?.image3?.[0];
        const image4 = req.files?.image4?.[0];
        const newImages = [image1, image2, image3, image4].filter((item) => item !== undefined);
        
        // Helper function to save a single image (same as in addplot)
        const saveImage = async (imageFile, isFrontImage = false) => {
            if (!imageFile) return null;
            
            let imageKitSucceeded = false;
            let imageUrl = null;
            
            // Try ImageKit first if configured
            if (isImageKitConfigured && imagekit) {
                try {
                    const filePath = imageFile.path;
                    if (fs.existsSync(filePath)) {
                        const fileBuffer = fs.readFileSync(filePath);
                        const folderPath = isFrontImage ? "Plot/Front" : "Plot";
                        
                        const result = await imagekit.upload({
                            file: fileBuffer,
                            fileName: imageFile.originalname,
                            folder: folderPath,
                        });
                        
                        fs.unlink(filePath, (err) => {
                            if (err) console.error("Error deleting temp file:", err);
                        });
                        
                        imageUrl = result.url;
                        imageKitSucceeded = true;
                    }
                } catch (imageKitError) {
                    console.error(`❌ ImageKit upload failed: ${imageKitError.message}`);
                    console.log(`📦 Falling back to local storage...`);
                }
            }
            
            // Save locally if ImageKit not configured or ImageKit failed
            if (!imageKitSucceeded) {
                try {
                    const uploadsDir = path.join(__dirname, '..', 'uploads', 'plots');
                    if (!fs.existsSync(uploadsDir)) {
                        fs.mkdirSync(uploadsDir, { recursive: true });
                    }
                    
                    const filePath = imageFile.path;
                    if (!filePath || !fs.existsSync(filePath)) {
                        return null;
                    }
                    
                    const timestamp = Date.now();
                    const randomSuffix = Math.random().toString(36).substring(2, 8);
                    const ext = path.extname(imageFile.originalname) || '.jpg';
                    const baseName = path.basename(imageFile.originalname, ext).replace(/[^a-zA-Z0-9]/g, '_');
                    const prefix = isFrontImage ? 'front-' : '';
                    const newFileName = `${prefix}plot-${timestamp}-${randomSuffix}-${baseName}${ext}`;
                    const newFilePath = path.join(uploadsDir, newFileName);
                    
                    fs.copyFileSync(filePath, newFilePath);
                    if (fs.existsSync(newFilePath)) {
                        fs.unlinkSync(filePath);
                        imageUrl = `/uploads/plots/${newFileName}`;
                    }
                } catch (localSaveError) {
                    console.error(`❌ Local save error:`, localSaveError);
                    return null;
                }
            }
            
            return imageUrl;
        };
        
        // Handle front image update
        if (frontImageFile) {
            const newFrontImageUrl = await saveImage(frontImageFile, true);
            if (newFrontImageUrl) {
                updateData.frontImage = newFrontImageUrl;
            }
        }
        
        // Handle additional images update
        if (newImages.length > 0) {
            const existingPlot = await Plot.findByPk(plotId);
            let existingImages = [];
            if (existingPlot && existingPlot.image) {
                if (Array.isArray(existingPlot.image)) {
                    existingImages = existingPlot.image;
                } else if (typeof existingPlot.image === 'string') {
                    try {
                        existingImages = JSON.parse(existingPlot.image);
                    } catch {
                        existingImages = [existingPlot.image];
                    }
                }
            }
            
            const newImageUrls = await Promise.all(
                newImages.map(async (item) => await saveImage(item, false))
            );
            const validNewImages = newImageUrls.filter(url => url !== null);
            
            // Combine existing and new images
            updateData.image = [...existingImages, ...validNewImages];
        }
        
        const [updatedCount] = await Plot.update(updateData, {
            where: { id: plotId }
        });

        if (updatedCount === 0) {
            return res.status(404).json({ message: "Plot not found", success: false });
        }

        const updatedPlot = await Plot.findByPk(plotId);
        res.json({ message: "Plot updated successfully", success: true, plot: updatedPlot });
    } catch (error) {
        console.error("Error updating plot:", error);
        res.status(500).json({ message: "Server Error", success: false });
    }
};

const singleplot = async (req, res) => {
    try {
        const plotId = parseInt(req.params.id);
        if (isNaN(plotId) || plotId <= 0) {
            return res.status(400).json({ message: "Invalid plot ID", success: false });
        }

        const plot = await Plot.findByPk(plotId);
        if (!plot) {
            return res.status(404).json({ message: "Plot not found", success: false });
        }

        const plotData = plot.toJSON();
        const baseUrl = `${req.protocol}://${req.get('host')}`;
        
        // Convert frontImage to full URL if it's a local path
        if (plotData.frontImage && typeof plotData.frontImage === 'string' && plotData.frontImage.startsWith('/uploads/')) {
            plotData.frontImage = `${baseUrl}${plotData.frontImage}`;
        }
        
        // Ensure images and amenities are arrays
        if (!Array.isArray(plotData.image)) {
            if (typeof plotData.image === 'string') {
                try {
                    plotData.image = JSON.parse(plotData.image);
                } catch {
                    plotData.image = [plotData.image];
                }
            } else {
                plotData.image = [];
            }
        }
        
        plotData.image = plotData.image.map(img => {
            if (typeof img === 'string' && img.startsWith('/uploads/')) {
                return `${baseUrl}${img}`;
            }
            return img;
        });
        
        if (!Array.isArray(plotData.amenities)) {
            if (typeof plotData.amenities === 'string') {
                try {
                    plotData.amenities = JSON.parse(plotData.amenities);
                } catch {
                    plotData.amenities = [];
                }
            } else {
                plotData.amenities = [];
            }
        }

        res.json({ success: true, plot: plotData });
    } catch (error) {
        console.error("Error fetching plot:", error);
        res.status(500).json({ message: "Server Error", success: false });
    }
};

export { addplot, listplot, removeplot, updateplot, singleplot };

